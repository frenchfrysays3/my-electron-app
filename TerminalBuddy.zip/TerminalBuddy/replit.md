# Electron Music Player

## Overview
A desktop music player application built with Electron and TypeScript. Features a modern, purple-gradient UI with playlist management, playback controls, and volume adjustment.

## Project Structure
- `src/main.ts` - Electron main process (handles window creation and file dialogs)
- `src/renderer.ts` - Renderer process (handles UI logic and audio playback)
- `public/index.html` - Application HTML interface
- `public/styles.css` - Modern purple-gradient styling
- `dist/` - Compiled TypeScript output (generated)
- `tsconfig.json` - TypeScript configuration
- `package.json` - Project dependencies and scripts

## Features
- Browse and select audio files (MP3, WAV, OGG, M4A, FLAC)
- Playlist management with visual feedback
- Play/pause, next, previous controls
- Progress bar with seek functionality
- Volume control
- Clean, modern UI with gradient styling

## Technology Stack
- **Electron 39.0.0** - Desktop application framework
- **TypeScript 5.9.3** - Type-safe JavaScript
- **Node.js 20** - Runtime environment

## Development
- Run `npm run build` to compile TypeScript
- Run `npm start` to build and launch the application
- The app runs in VNC mode for desktop GUI display

## System Dependencies
Electron requires various system libraries installed via Nix:
- Graphics: mesa, libgbm, libdrm, cairo
- X11: libX11, libxcb, libxkbcommon, various X extensions
- Desktop: gtk3, glib, gdk-pixbuf, atk, pango
- Audio: alsa-lib
- System: nss, nspr, cups, dbus, expat, libnotify

## Recent Changes
- 2025-10-30: Initial project setup with TypeScript and Electron
- 2025-10-30: Created music player UI with modern styling
- 2025-10-30: Configured Electron to run with --no-sandbox and --disable-gpu flags for Replit environment
- 2025-10-30: Installed all required system dependencies for Electron

## User Preferences
None specified yet.
